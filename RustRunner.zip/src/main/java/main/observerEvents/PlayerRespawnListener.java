package main.observerEvents;

import java.io.File;

/** Listener for low-level player events coming from the Player model. */
public class PlayerRespawnListener implements EventListener {

    /**
     * Called when the player has just Respawned.
     */
    void onPlayerRespawn() {

    }

    @Override
    public void update(String eventType, File file) {

    }
}
